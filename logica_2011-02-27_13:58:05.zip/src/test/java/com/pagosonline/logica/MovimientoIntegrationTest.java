package com.pagosonline.logica;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Movimiento.class)
public class MovimientoIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
