package com.pagosonline.logica;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Cliente.class)
public class ClienteIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
    
}
