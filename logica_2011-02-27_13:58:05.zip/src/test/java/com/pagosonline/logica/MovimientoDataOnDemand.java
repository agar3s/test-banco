package com.pagosonline.logica;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Movimiento.class)
public class MovimientoDataOnDemand {
}
