package com.pagosonline.logica;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Cuenta.class)
public class CuentaDataOnDemand {
}
