package com.pagosonline.logica;


public enum TipoMovimiento {

    DEBITO, CREDITO
}
